import 'dart:ui';

class AppColors {
  static const green = const Color(0xff3ab098);
  static const lightgray = const Color(0xffcecfd1);
  static const darkgray = const Color(0xffadaeb0);
}
